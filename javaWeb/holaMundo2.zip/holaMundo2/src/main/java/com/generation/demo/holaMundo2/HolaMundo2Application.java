package com.generation.demo.holaMundo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolaMundo2Application {

	public static void main(String[] args) {
		SpringApplication.run(HolaMundo2Application.class, args);
	}

}
